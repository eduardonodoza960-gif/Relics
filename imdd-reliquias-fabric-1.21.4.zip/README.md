# IMDD Relíquias (Fabric 1.21.4)
Mod completo com as 20 Relíquias no menu de 27 slots.
